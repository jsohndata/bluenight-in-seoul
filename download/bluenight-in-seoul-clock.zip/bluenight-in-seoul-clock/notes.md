## Text
현재 시간

<br>

## Bookmarks
* [Google Font: Orbitron](https://fonts.google.com/specimen/Orbitron?preview.text=10:11&preview.text_type=custom)
* [Fotor](https://www.fotor.com/)
* [CSS Gradient](https://cssgradient.io/)
* [CSS Box-Shadow](https://html-css-js.com/css/generator/box-shadow/)
* [Favicon](https://favicon.io/favicon-converter/)
* [toLocaleString](https://www.w3schools.com/jsref/jsref_tolocalestring.asp)

<br>

## Code
1) document.querySelector("h1").innerHTML = "서울";
2) document.querySelector("h1").innerHTML = "香港";
3) document.querySelector("h1").innerHTML = "東京";

<br>

## toLocaleString()
Convert a date, number or currency value to a string using a specific locale or formatting options.

When applied to a `Date` object, `toLocaleString()` returns a string representation of the date and time in the specified locale. 

It can take two arguments: 
1) `locale` string that specifies the language and region to use for formatting.

2) `options object` can include properties such as weekday, year, month, day, hour, minute, second, and timeZone, which allow you to customize the format of the output string.

<br>

## Homeage
[Blue Night in Seoul<Last Hope>](https://scmscx.com/map/G8V4Rh2D)
